// [routes/auth.js — Discord OAuth2 flow]
const express = require('express');
const fetch   = require('node-fetch');
const router  = express.Router();

const CLIENT_ID     = process.env.DISCORD_CLIENT_ID;
const CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET;
const REDIRECT_URI  = process.env.DISCORD_REDIRECT_URI || 'http://localhost:3000/auth/callback';

router.get('/discord', (req, res) => {
  const url = new URL('https://discord.com/api/oauth2/authorize');
  url.searchParams.set('client_id',     CLIENT_ID);
  url.searchParams.set('redirect_uri',  REDIRECT_URI);
  url.searchParams.set('response_type', 'code');
  url.searchParams.set('scope',         'identify');
  res.redirect(url.toString());
});

router.get('/callback', async (req, res) => {
  const { code } = req.query;
  if (!code) return res.redirect('/login?error=no_code');
  try {
    const tokenRes = await fetch('https://discord.com/api/oauth2/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        client_id:     CLIENT_ID,
        client_secret: CLIENT_SECRET,
        grant_type:    'authorization_code',
        code,
        redirect_uri:  REDIRECT_URI
      })
    });
    const tok = await tokenRes.json();
    if (!tok.access_token) throw new Error('no access_token');

    const userRes = await fetch('https://discord.com/api/users/@me', {
      headers: { Authorization: `Bearer ${tok.access_token}` }
    });
    const user = await userRes.json();

    req.session.user = {
      id:          user.id,
      username:    user.username,
      avatar:      user.avatar,
      accessToken: tok.access_token
    };
    res.redirect('/dashboard');
  } catch (err) {
    console.error('[auth]', err.message);
    res.redirect('/login?error=oauth_failed');
  }
});

router.get('/logout', (req, res) => req.session.destroy(() => res.redirect('/login')));

module.exports = router;
