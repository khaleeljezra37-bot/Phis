// panel.js — shared sidebar + utilities injected into every panel page

const SIDEBAR = `
<div class="sidebar">
  <div class="sb-logo">
    <div class="sb-mark">X</div>
    <div class="sb-name">Xenart</div>
  </div>
  <nav class="sb-nav">
    <div class="nav-section">
      <div class="nav-label">Panel</div>
      <a href="/dashboard" class="nav-item" data-path="/dashboard">
        <span class="nav-icon">📊</span> Dashboard
      </a>
      <a href="/settings" class="nav-item" data-path="/settings">
        <span class="nav-icon">🔗</span> Link Generator
      </a>
      <a href="/tools" class="nav-item" data-path="/tools">
        <span class="nav-icon">🔧</span> Tools
      </a>
    </div>
  </nav>
  <div class="sb-footer">
    <div class="user-chip">
      <img class="user-av" id="user-av" src="" alt="">
      <div style="flex:1;min-width:0">
        <div class="user-n" id="user-n">…</div>
        <div class="user-r">Operator</div>
      </div>
      <a href="/auth/logout" class="logout-btn" title="Logout">⏏</a>
    </div>
  </div>
</div>`;

function initPanel() {
  const ph = document.getElementById('sidebar-ph');
  if (ph) ph.outerHTML = SIDEBAR;

  // highlight active
  const p = window.location.pathname;
  document.querySelectorAll('.nav-item[data-path]').forEach(el => {
    if (el.dataset.path === p || (p === '/' && el.dataset.path === '/dashboard'))
      el.classList.add('active');
  });

  // load user
  fetch('/api/me').then(r => r.json()).then(u => {
    const n = document.getElementById('user-n');
    const a = document.getElementById('user-av');
    if (n) n.textContent = u.username || 'Operator';
    if (a) {
      a.src = u.id && u.avatar
        ? `https://cdn.discordapp.com/avatars/${u.id}/${u.avatar}.png?size=64`
        : `https://ui-avatars.com/api/?name=${encodeURIComponent(u.username||'X')}&background=a855f7&color=fff&size=64`;
    }
  }).catch(() => {});
}

/* ── toast ── */
function toast(msg, type = 'info') {
  let stack = document.querySelector('.toast-stack');
  if (!stack) { stack = document.createElement('div'); stack.className = 'toast-stack'; document.body.appendChild(stack); }
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${{success:'✅',error:'❌',info:'💜'}[type]||'💜'}</span><span>${msg}</span>`;
  stack.appendChild(el);
  setTimeout(() => { el.style.opacity='0'; el.style.transform='translateX(110%)'; }, 3000);
  setTimeout(() => el.remove(), 3400);
}

/* ── clipboard ── */
function copy(text, label = 'Copied!') {
  navigator.clipboard.writeText(text).then(() => toast(label, 'success')).catch(() => toast('Copy failed', 'error'));
}

/* ── time ago ── */
function ago(ds) {
  const s = Math.floor((Date.now() - new Date(ds)) / 1000);
  if (s < 60)   return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s/60)}m ago`;
  if (s < 86400)return `${Math.floor(s/3600)}h ago`;
  return `${Math.floor(s/86400)}d ago`;
}

/* ── mask cookie ── */
function maskCookie(c) {
  if (!c || c.length < 20) return c || '—';
  return c.slice(0,22) + '…' + c.slice(-8);
}

document.addEventListener('DOMContentLoaded', initPanel);
